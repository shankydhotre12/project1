package springmvcprojdao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;


import springmvcprojmodel.product;

@Component
public class productdao {

	@Autowired
	private HibernateTemplate hibernatetemplate;
	
	
	//Insert product details
	@Transactional
	public void insertproduct(product product)
	{
	   this.hibernatetemplate.saveOrUpdate(product);
	}
	
	//Get all Products 
	
	public List<product> getallproduct()
	{
		List<product> products= this.hibernatetemplate.loadAll(product.class);
		return products;
	}
	
	//delete product
	@Transactional
	public int deleteproduct(int id)
	
	{
	   product product=this.hibernatetemplate.get(product.class, id)	;
	   this.hibernatetemplate.delete(product);
	return id;
	}
	
	//get single product
	
	public product getsingleproduct(int id)
	{
		
		return this.hibernatetemplate.get(product.class,id);
		//return product;
		
	}
	
	//update product data
	@Transactional
	public void updateproduct(int id,String name,String pdescription,long price)
	{
		
		product st=this.hibernatetemplate.get(product.class,id);
		st.setPname(name);
		st.setPdescription(pdescription);
		st.setPrice(price);
		this.hibernatetemplate.update(st);
		//return id;
	}
	
	public HibernateTemplate getHibernatetemplate() {
		return hibernatetemplate;
	}

	public void setHibernatetemplate(HibernateTemplate hibernatetemplate) {
		this.hibernatetemplate = hibernatetemplate;
	}

}
