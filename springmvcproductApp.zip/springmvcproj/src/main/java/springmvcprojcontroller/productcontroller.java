package springmvcprojcontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import springmvcprojmodel.product;

@Controller
public class productcontroller {
	
	@Autowired
	private springmvcprojdao.productdao productdao;
	//GET DATA
	@RequestMapping("/")
	public String home(Model m)
	{
		List <product> products=productdao.getallproduct();
		m.addAttribute("products",products);
		return "index";
	}
 //add products
	@RequestMapping("/add")
	public String Addproduct()
	{
		return "addproductform";
	}
	
	//handle add products forms
	@RequestMapping(value="/handle_product", method=RequestMethod.POST)
	public RedirectView handleproduct(@ModelAttribute product product,HttpServletRequest request)
	{
		this.productdao.insertproduct(product);
		System.out.println(product);
		RedirectView re=new RedirectView();
		re.setUrl(request.getContextPath()+"/");
		return re;
		
	}
	
	//DELETE products
	
	@RequestMapping(value="/delete/{productid}",method=RequestMethod.GET)
	public RedirectView deleteproduct(@PathVariable("productid") int productid,HttpServletRequest request)
	{
		productdao.deleteproduct(productid);
		RedirectView re=new RedirectView();
		re.setUrl( request.getContextPath()+"/");
		return re;
		
	}
	
	//update products
	@RequestMapping("/updateproduct/{productid}")
	public String updateform(@PathVariable("productid") int id,Model m)
	{
		product product =this.productdao.getsingleproduct(id);
		m.addAttribute("product", product);
		return "update_form";
		
	}
	
	
}
