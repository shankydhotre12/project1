package springmvcprojmodel;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class product {
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String pname;
	private String pdescription;
	private long price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdescription() {
		return pdescription;
	}
	public void setPdescription(String pdescription) {
		this.pdescription = pdescription;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public product(int id, String pname, String pdescription, long price) {
		super();
		this.id = id;
		this.pname = pname;
		this.pdescription = pdescription;
		this.price = price;
	}
	public product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "product [id=" + id + ", pname=" + pname + ", pdescription=" + pdescription + ", price=" + price + "]";
	}
	
	
	
	
	

}
